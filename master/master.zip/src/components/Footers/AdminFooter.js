import { Container, Row, Col, Nav, NavItem, NavLink } from "reactstrap";

const Footer = () => {
  return (
    <footer className="footer">
  {/*  {/*  {  <Row className="align-items-center justify-content-xl-between">
        <Col xl="6">
          <div className="copyright text-center text-xl-left text-muted">
            © {new Date().getFullYear()}{" "}
             <a
              className="font-weight-bold ml-1"
              href="https://www.creative-tim.com?ref=adr-admin-footer"
              rel="noopener noreferrer"
              target="_blank"
            >
              Creative Tim
            </a> 
          </div>
        </Col>

        <Col xl="6">
          <Nav className="nav-footer justify-content-center justify-content-xl-end">
            <NavItem>
             <NavLink
                href="https://www.creative-tim.com?ref=adr-admin-footer"
                rel="noopener noreferrer"
                target="_blank"
              >
                Creative Tim
              </NavLink> 
            </NavItem>

            <NavItem>
            <NavLink
                href="https://www.creative-tim.com/presentation?ref=adr-admin-footer"
                rel="noopener noreferrer"
                target="_blank"
              >
                About Us
              </NavLink> 
            </NavItem>

            <NavItem>
             <NavLink
                href="http://blog.creative-tim.com?ref=adr-admin-footer"
                rel="noopener noreferrer"
                target="_blank"
              >
                Blog
              </NavLink> 
            </NavItem>

            <NavItem>
               <NavLink
                href="https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md?ref=adr-admin-footer"
                rel="noopener noreferrer"
                target="_blank"
              >
                MIT License
              </NavLink> 
            </NavItem>
          </Nav>


          </Col>
      </Row>
 */}
 



          
          

<div class="container-fluid">
   <div class="row">
      <div class="col-sm-3" >
      <h1>FAQ<hr/></h1>
      <h6>What is our working hour</h6>
      <h6>How u Contact us?</h6>
      </div>
      <div class="col-sm-3" >
      <h1>Contact us<hr/></h1>
      <h6>bc@gmail.com</h6>
      <h6>123456789</h6>
       </div>
      <div class="col-sm-3" >
      <h1>Privacy Policy<hr/></h1>
      <h6>With Termify you can easily generate and download your customized and up to date Privacy Policy

   </h6>
      
      </div>
      <div class="col-sm-3">
      <h1>Blogs<hr/></h1>
      <img src="https://static.wixstatic.com/media/d7875f_ad5f211986d8404b8879b30fb9a6be35~mv2.png/v1/fill/w_26,h_26,al_c,q_85,usm_0.66_1.00_0.01/d7875f_ad5f211986d8404b8879b30fb9a6be35~mv2.webp" alt=""></img>
      <img src="https://static.wixstatic.com/media/263c6eefe13c431681f9363e2e92ddb7.png/v1/fill/w_26,h_26,al_c,q_85,usm_0.66_1.00_0.01/263c6eefe13c431681f9363e2e92ddb7.webp" alt=""></img>
      <img src="https://static.wixstatic.com/media/48a2a42b19814efaa824450f23e8a253.png/v1/fill/w_26,h_26,al_c,q_85,usm_0.66_1.00_0.01/48a2a42b19814efaa824450f23e8a253.webp" alt=""></img>
     <img src="https://static.wixstatic.com/media/e316f544f9094143b9eac01f1f19e697.png/v1/fill/w_26,h_26,al_c,q_85,usm_0.66_1.00_0.01/e316f544f9094143b9eac01f1f19e697.webp" alt=""></img>
     <img src="https://static.wixstatic.com/media/a1b09fe8b7f04378a9fe076748ad4a6a.png/v1/fill/w_26,h_26,al_c,q_85,usm_0.66_1.00_0.01/a1b09fe8b7f04378a9fe076748ad4a6a.webp" alt=""></img>
     <img src="https://static.wixstatic.com/media/28e77d0b179d4121891d847ed43de6cc.png/v1/fill/w_26,h_26,al_c,q_85,usm_0.66_1.00_0.01/28e77d0b179d4121891d847ed43de6cc.webp" alt=""></img>
      </div>
    </div>
  </div>
   <div className="works">
  <h2>© 2020 by Beautiful Concepts Company</h2>
</div>

 </footer>
  );
};

export default Footer;