import React from 'react';

const team=[
    {
        id:'1',
        team:'2 members',
        name:['rahul ,','abhi,']
    },
    {
        id:'2',
        team:'3 member',
        name:['kali ,','kaliya ,','ha ,']
    },
    {
        id:'3',
        team:'4 member',
        name:['kali ,','kaliya ,','ha ,','pinky ,']
    },
    {
        id:'4',
        team:'5 member',
        name:['kali ,','kaliya ,','ha ,','pinky ,','pinky ,']
    }
]
   

export default team;