import React from 'react'

function Approve() {
    return (
        <div>
            <h1 style={{padding :"170px"}}>
                your request have approve
            </h1>
        </div>
    )
}

export default Approve
