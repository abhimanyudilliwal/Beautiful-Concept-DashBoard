
const img1 =  '/hello.jpg'

const free=[
    {     
        id:1,
        title: '7 day Assisment',
        Describtion:'While your property description is the narrative base of your marketing efforts',
        link:'add',
        price: "4000",
        discount: '100%',
        total:'0',
    
        
    },
    {     id:2,
        title: 'Virtual Employee',
        Describtion:'hello Sir1Property management is the oversight of real estate by a third party Property managers are generally responsible for the day to day operations of the real ',
        link:'add', 
        price: "2000",
        discount: '100%',
        total:'0',

    },
    {     id:3,
        title: 'Pay As you Go',
        Describtion:'We provide virtual assistance via 360 Virtual Assistants (360 VA)- a business support unit within 360 Solutions founded in 2008 delivering remotely in Dubai, ',
        link:'add',
        price: "400",
        discount: '100%',
        total:'0',
    },
    {     id:4,
        title: 'Social media',
        Describtion:'We cover so many services, we are more than just a virtual assistant for small business or a lifestyle management firm we are truly a professional and elite level of ',
        link:'add',
        price: "10000",
        discount: '100%',
        total:'0',
    },
    {     id:5,
        title: 'Web and App Development',
        Describtion:'Working in a virtual team presents many challenges. When you cant see your colleagues face-to-face, and you dont have the social interactions that build relationships and rapport it can be difficult to establish trust ',
        link:'add',
        price: "6000",
        discount: '100%',
        total:'0',
    },
]



export default free;