const monthly=[
    {     id:1,
        title: 'Data entry Service',
        link:'add',
        price: "2000",
        discount: '50%',
        total:'1000',
        Describtion:'Data Entry Operator job description should contain the following duties and responsibilitie Transfer data from paper formats into database systemsType in data provided'
    },
    {     id:2,
        title: 'Project  Management',
        link:'add',
        price: "5000",
        discount: '40%',
        total:'2000',
        Describtion:'Project management is the process of leading the work of a team to achieve goals and meet success criteria at a specified time. The primary challenge of project management is to achieve all of the project goals within the given constraints.'
    },
    {       id:3,
        title: 'Virtual Employee',
        link:'add',
        price: "4000",
        discount: '30%',
        total:'1700',
        Describtion:'Working in a virtual team presents many challenges. When you cant see your colleagues face-to-face, and you dont have the social interactions that build relationships and rapport it can be difficult to establish trust '
    },
    {     id:4,
        title: '7 Days Assistants',
        link:'add',
        price: "3500",
        discount: '10%',
        total:'3300',
        Describtion:'We cover so many services, we are more than just a virtual assistant for small business or a lifestyle management firm we are truly a professional and elite level of business assistance Dont just think of us for the little tasks '
    },
    {     id:5,
        price: "4500",
        discount: '20%',
        total:'4000',
        title: 'Social media management',
        Describtion:'Social Media Manager Job Description Template We are searching for a talented Social Media Manager to represent our company by building a social media presence for our brands. maintaining a solid online presence.Monitoring the companys brand on social media. ',
        link:'add'
    },
    {     id:6,
        price: "18000",
        discount: '30%',
        total:'15000',
        title: 'Pay as you go',
        link:'add',
        Describtion:'Pay as you go is a cost model for cloud services that encompasses both subscription-based and consumption-based models '
        
    },
    ]
export default monthly