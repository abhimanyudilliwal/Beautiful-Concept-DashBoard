const yearly=[
    {    
        id:1,
        title: 'Assistants 360',
        price: "20000",
        discount: '10%',
        total:'18000',
        Describtion:'We provide virtual assistance via 360 Virtual Assistants (360 VA)- a business support unit within 360 Solutions founded in 2008 delivering remotely in Dubai ',
        link:'add'
    },

    {  
    id:2,
    title: '7 Days Assistants',
    price: "120000",
    discount: '10%',
    total:'100000',
    Describtion:'We cover so many services, we are more than just a virtual assistant for small business or a lifestyle management firm we are truly a professional and elite level of business assistance ',
    link:'add'
},
    {    id:3,
        title: 'Virtual Employee',
        price: "21000",
        discount: '20%',
        total:'200000',
        Describtion:'Working in a virtual team presents many challenges. When you cant see your colleagues face-to-face, and you dont have the social interactions that build relationships and rapport it can be difficult to establish trust ',
        link:'add'
    },
    {     id:4,
        title: '7 Days Assistants',
        price: "90000",
        discount: '10%',
        total:'15552',
        Describtion:'We cover so many services, we are more than just a virtual assistant for small business or a lifestyle management firm we are truly a professional and elite level of business assistance ',
        link:'add'
    },
    {     id:5,
        price: "2000000",
        discount: '10%',
        total:'35454',
        title: 'Social media management',
        Describtion:'Social Media Manager Job Description Template We are searching for a talented Social Media Man.',
        link:'add'
    },
    {     id:6,
        price: "346500",
        discount: '10%',
        total:'65564',
        title: 'Pay as you go',
        Describtion:'Pay as you go is a cost model for cloud services that encompasses both subscription-based and consumption-based models, in contrast to traditional IT cost model  ',
        link:'add'
    },
    ]
export default yearly